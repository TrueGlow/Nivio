# Nivio Landing Page

This is the official landing page for Nivio — premium, sustainable flip flops inspired by the tides.

## Features
- Lightweight landing page
- Mobile-first responsive design
- Netlify and GitHub deploy-ready
